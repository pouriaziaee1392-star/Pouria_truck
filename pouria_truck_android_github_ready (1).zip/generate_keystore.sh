#!/bin/sh
# Generate a new keystore for signing (uses keytool from JDK)
# Edit the alias, keystore filename and passwords as desired.

KEYSTORE_FILE=release-keystore.jks
KEY_ALIAS=pouria_alias
KEY_PASSWORD=changeit
STORE_PASSWORD=changeit
VALIDITY=10000
NAME="CN=Pouria, OU=Dev, O=PouriaTruck, L=Unknown, ST=Unknown, C=IR"

echo "Generating keystore: $KEYSTORE_FILE (alias: $KEY_ALIAS)"
keytool -genkeypair -v -keystore "$KEYSTORE_FILE" -storepass "$STORE_PASSWORD" \
  -alias "$KEY_ALIAS" -keypass "$KEY_PASSWORD" -keyalg RSA -keysize 2048 -validity $VALIDITY \
  -dname "$NAME"

echo "Generated keystore: $KEYSTORE_FILE"
echo "Now copy/move the keystore to the project root and update signing.properties (or rename signing.properties.example)."
