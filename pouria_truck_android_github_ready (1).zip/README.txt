Pouria Truck - Android Studio project (wrapper for the web prototype)
=================================================================

این پروژه یک بسته ساده اندرویدی است که بازی وبِ Pouria Truck (HTML5 canvas) را در یک WebView قرار می‌دهد.
نام پکیج: com.pouria.truck
نسخه: 0.1 prototype

چه چیزهایی داخل است:
- app/src/main/assets/*  -> فایل‌های بازی وب (index.html, game.js, style.css, README.txt)
- app/src/main/java/com/pouria/truck -> MainActivity.kt
- app/src/main/AndroidManifest.xml
- فایل‌های Gradle (پایگاه) برای اجرا در Android Studio

نحوه ساخت APK در Android Studio:
1. فایل ZIP را استخراج کن.
2. در Android Studio: File -> Open... -> فولدر پروژه (جایی که settings.gradle هست) را باز کن.
3. صبر کن Gradle پروژه را سینک کنه. (اگر Gradle wrapper موجود نیست، Android Studio از نسخه محلی استفاده خواهد کرد یا ازت می‌پرسه wrapper بسازد)
4. Build -> Build Bundle(s) / APK(s) -> Build APK(s)
5. برای انتشار، باید اپ را با keystore خودت Sign کنی: Build -> Generate Signed Bundle / APK...

نکات مهم:
- برای اجرای محلی بازی (بدون اینترنت)، فایل‌های بازی به assets اضافه شده‌اند. اگر بازی از منابع شبکه استفاده می‌کند، مطمئن شو مجوز اینترنت فعال است (در AndroidManifest.xml قرار دارد).
- اگر می‌خوای نام پکیج یا تنظیمات SDK را تغییر بدی، از فایل app/build.gradle استفاده کن.
- برای پشتیبانی بهتر از fullscreen و orientation، MainActivity را تغییر بده و تنظیمات لازم را به AndroidManifest اضافه کن.

امیدوارم کمک کنه! اگر می‌خوای، من می‌تونم نسخه Java به جای Kotlin بسازم، یا فایل‌های آیکون، اسپلش، پشتیبانی از fullscreen و orientation، و همین‌طور راهنمای دقیق برای امضای keystore را اضافه کنم.


---
Additional build helper files added:
- signing.properties.example
- generate_keystore.sh (use keytool to generate a keystore)
- build_release.sh (runs ./gradlew assembleRelease)
- gradlew placeholder (Android Studio will generate a real wrapper)

Steps to produce a release-signed APK from this project:
1) Generate a keystore (or use your existing one):
   sh generate_keystore.sh
   Move the generated keystore (e.g., release-keystore.jks) into the project root.
2) Copy signing.properties.example -> signing.properties and fill values (KEYSTORE_FILE, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD).
3) Open project in Android Studio and let it sync; or generate a Gradle wrapper by running `gradle wrapper`.
4) From project root run: sh build_release.sh
5) The release APK will be under app/build/outputs/apk/release/

Security note: keep your keystore and passwords private. Do not commit signing.properties with real passwords to VCS.
