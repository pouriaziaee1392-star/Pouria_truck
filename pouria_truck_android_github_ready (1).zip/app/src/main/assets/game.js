\
/*
  Pouria Truck - simple HTML5 canvas prototype
  Controls: Left/Right arrows to steer, Up to accelerate, Down to brake, R to reset.
  Objective: Pick up and deliver boxes (checkpoints) to earn money.
*/
(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;

  // UI
  const statusEl = document.getElementById('status');
  const startBtn = document.getElementById('startBtn');
  const moneyEl = document.getElementById('money');
  const deliveredEl = document.getElementById('delivered');
  const speedEl = document.getElementById('speed');

  // Game state
  let running = false;
  let money = 0, delivered = 0;
  let keys = {};
  let road = { laneCount: 3, laneWidth: 200 };
  let cameraY = 0;
  let tick = 0;

  // Truck
  let truck = {
    x: W/2,
    y: H - 140,
    width: 80,
    height: 150,
    speed: 0,
    angle: 0,
    maxSpeed: 8,
    accel: 0.12,
    friction: 0.03,
  };

  // Checkpoints (pickup -> delivery)
  let tasks = [];
  function spawnTask(y) {
    const lane = Math.floor(Math.random() * road.laneCount);
    const laneCenter = W/2 - (road.laneCount/2 - 0.5)*road.laneWidth + lane*road.laneWidth;
    return {
      pickupX: laneCenter,
      pickupY: y - 600,
      deliveryX: laneCenter + (Math.random()*200-100),
      deliveryY: y - 1200,
      picked: false,
      delivered: false,
      reward: 100 + Math.floor(Math.random() * 200)
    };
  }

  for (let i=1;i<=6;i++) tasks.push(spawnTask(i*1200));

  // Input
  window.addEventListener('keydown', e => { keys[e.key]=true; if(e.key==='r' || e.key==='R') resetGame(); });
  window.addEventListener('keyup', e => { keys[e.key]=false; });

  function startGame() {
    running = true;
    statusEl.textContent = 'در حال بازی — مسیر را طی کن و بارها را تحویل بده!';
    startBtn.disabled = true;
    tick = 0;
    loop();
  }
  startBtn.addEventListener('click', startGame);

  function resetGame() {
    money = 0; delivered = 0;
    moneyEl.textContent = 'پول: ' + money;
    deliveredEl.textContent = 'تحویل: ' + delivered;
    cameraY = 0;
    truck.x = W/2; truck.speed = 0;
    tasks = [];
    for (let i=1;i<=6;i++) tasks.push(spawnTask(i*1200));
    statusEl.textContent = 'بازی ریست شد';
  }

  function update() {
    tick++;
    // Controls
    if (keys['ArrowUp'] || keys['w']) truck.speed += truck.accel;
    if (keys['ArrowDown'] || keys['s']) truck.speed -= truck.accel*2;
    if (keys['ArrowLeft'] || keys['a']) truck.x -= 3 + truck.speed*0.6;
    if (keys['ArrowRight'] || keys['d']) truck.x += 3 + truck.speed*0.6;

    // Limit
    if (truck.speed > truck.maxSpeed) truck.speed = truck.maxSpeed;
    if (truck.speed < -1) truck.speed = -1;
    truck.speed -= truck.friction;
    if (Math.abs(truck.speed) < 0.01) truck.speed = 0;

    // Camera moves with truck speed
    cameraY += truck.speed * 2;

    // Boundaries (road)
    const roadLeft = W/2 - (road.laneCount/2)*road.laneWidth;
    const roadRight = roadLeft + road.laneCount*road.laneWidth;
    if (truck.x < roadLeft + truck.width/2) truck.x = roadLeft + truck.width/2;
    if (truck.x > roadRight - truck.width/2) truck.x = roadRight - truck.width/2;

    // Tasks interactions
    tasks.forEach(t => {
      if (!t.picked) {
        const sx = t.pickupX, sy = t.pickupY + cameraY;
        if (Math.abs(truck.x - sx) < 60 && Math.abs(truck.y - sy) < 90) {
          t.picked = true;
          statusEl.textContent = 'بار بارگیری شد! حالا آن را تحویل بده.';
        }
      } else if (t.picked && !t.delivered) {
        const sx = t.deliveryX, sy = t.deliveryY + cameraY;
        if (Math.abs(truck.x - sx) < 60 && Math.abs(truck.y - sy) < 90) {
          t.delivered = true;
          money += t.reward;
          delivered += 1;
          moneyEl.textContent = 'پول: ' + money;
          deliveredEl.textContent = 'تحویل: ' + delivered;
          statusEl.textContent = 'تحویل موفق — پول دریافت شد: ' + t.reward;
        }
      }
    });

    // Spawn farther tasks if needed
    if (tasks.length < 8) {
      tasks.push(spawnTask((tasks.length+1)*1200 + Math.random()*800));
    }

    speedEl.textContent = 'سرعت: ' + Math.round(truck.speed*10);
  }

  function drawRoad() {
    const roadLeft = W/2 - (road.laneCount/2)*road.laneWidth;
    const roadRight = roadLeft + road.laneCount*road.laneWidth;
    // Grass
    ctx.fillStyle = '#154b1f';
    ctx.fillRect(0,0,W,H);
    // Road
    ctx.fillStyle = '#333';
    ctx.fillRect(roadLeft,0,roadRight-roadLeft,H);
    // Lane lines
    ctx.strokeStyle = '#f3f3f3';
    ctx.lineWidth = 4;
    for (let i=1;i<road.laneCount;i++) {
      const x = roadLeft + i*road.laneWidth;
      // center dashed line
      const dashH = 40;
      for (let y = -((cameraY)% (dashH*2)); y < H; y += dashH*2) {
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x, y+dashH);
        ctx.stroke();
      }
    }
    // road borders
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 6;
    ctx.strokeRect(roadLeft, 0, roadRight-roadLeft, H);
  }

  function drawTruck() {
    ctx.save();
    ctx.translate(truck.x, truck.y);
    // body
    ctx.fillStyle = '#ff7b00';
    ctx.fillRect(-truck.width/2, -truck.height/2, truck.width, truck.height);
    // cabin
    ctx.fillStyle = '#fff';
    ctx.fillRect(-truck.width/2 + 8, -truck.height/2, truck.width*0.5, truck.height*0.4);
    // wheels
    ctx.fillStyle = '#222';
    const wheelW = 18, wheelH = 10;
    ctx.fillRect(-truck.width/2 + 6, truck.height/2 - 18, wheelW, wheelH);
    ctx.fillRect(truck.width/2 - 24, truck.height/2 - 18, wheelW, wheelH);
    ctx.restore();
  }

  function drawTasks() {
    tasks.forEach(t => {
      // pickup
      if (!t.picked) {
        const px = t.pickupX, py = t.pickupY + cameraY;
        if (py > -200 && py < H + 200) {
          ctx.fillStyle = '#ffd166';
          ctx.fillRect(px-24, py-24, 48, 48);
          ctx.fillStyle = '#000';
          ctx.fillText('بار', px-10, py+5);
        }
      }
      // delivery
      if (t.picked && !t.delivered) {
        const dx = t.deliveryX, dy = t.deliveryY + cameraY;
        if (dy > -200 && dy < H + 200) {
          ctx.fillStyle = '#06d6a0';
          ctx.fillRect(dx-20, dy-20, 40, 40);
          ctx.fillStyle = '#00311a';
          ctx.fillText('مقصد', dx-16, dy+5);
        }
      }
    });
  }

  function loop() {
    if (!running) return;
    update();

    // draw
    ctx.clearRect(0,0,W,H);
    drawRoad();
    drawTasks();
    drawTruck();

    requestAnimationFrame(loop);
  }

  // initial
  statusEl.textContent = 'آماده — روی "شروع بازی" کلیک کن';
  moneyEl.textContent = 'پول: ' + money;
  deliveredEl.textContent = 'تحویل: ' + delivered;
  speedEl.textContent = 'سرعت: 0';

  // export for debugging (global)
  window.PouriaTruck = {
    reset: resetGame
  };
})();
