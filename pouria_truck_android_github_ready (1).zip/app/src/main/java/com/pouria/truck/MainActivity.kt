package com.pouria.truck

import android.os.Bundle
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        setContentView(webView)

        webView.loadUrl("file:///android_asset/splash.html")
        webView.postDelayed({
            webView.loadUrl("file:///android_asset/index.html")
        }, 2000)
    }
}
