#!/bin/sh
# Build release APK using the Gradle wrapper.
# Requires JDK and Android SDK + Android Studio or command-line tools.
# Make sure signing.properties exists in project root with proper values.

set -e
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

if [ ! -f "signing.properties" ]; then
  echo "signing.properties not found. Please copy signing.properties.example and fill your values."
  exit 1
fi

# Make gradlew executable if present
if [ -f "./gradlew" ]; then
  chmod +x ./gradlew
  ./gradlew clean assembleRelease
else
  echo "Gradle wrapper (gradlew) not found. Open the project in Android Studio or generate a Gradle wrapper."
  exit 1
fi
